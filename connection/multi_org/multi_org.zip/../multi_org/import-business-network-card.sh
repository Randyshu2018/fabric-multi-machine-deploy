#!/usr/bin/env bash
composer card import -f PeerAdmin@byfn-network-org1-only.card

composer card import -f PeerAdmin@byfn-network-org1.card

composer card import -f PeerAdmin@byfn-network-org2-only.card

composer card import -f PeerAdmin@byfn-network-org2.card