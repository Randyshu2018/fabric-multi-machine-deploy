#!/usr/bin/env bash
composer identity request -c PeerAdmin@byfn-network-org1-only -u admin -s adminpw -d alice

composer identity request -c PeerAdmin@byfn-network-org2-only -u admin -s adminpw -d bob