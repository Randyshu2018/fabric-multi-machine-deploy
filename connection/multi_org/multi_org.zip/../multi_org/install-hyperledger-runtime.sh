#!/usr/bin/env bash

composer runtime install -c PeerAdmin@byfn-network-org1-only -n tutorial-network

composer runtime install -c PeerAdmin@byfn-network-org2-only -n tutorial-network