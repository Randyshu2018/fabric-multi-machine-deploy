#!/usr/bin/env bash

./create-business-network-card.sh

./import-business-network-card.sh

./install-hyperledger-runtime.sh

./request-identity.sh

./start-business-network.sh